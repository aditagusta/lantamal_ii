<footer class="footer">
    <div class="container-fluid">
        
        <div class="copyright ml-auto">
           <a target="_blank" href="https://sukumaya.id/">Sukumaya.Id</a>
        </div>
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\lantamal2\resources\views/component/footer.blade.php ENDPATH**/ ?>
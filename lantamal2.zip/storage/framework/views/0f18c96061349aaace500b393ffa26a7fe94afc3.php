<?php $__env->startSection('title','Data Member'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page','Edit Member'); ?>
<div class="page-inner mt--5">
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="card">
                <div class="card-body" align=center>
                    <h1>PANDEKA LAUIK SAKTI</h1>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <?php if($message = Session::get('status')): ?>
            <div class="alert alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>

            <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('upmember')); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Username</label>
                    <input type="hidden" class="form-control" name="id_member" value="<?php echo e($data->id_member); ?>">
                    <input type="text" class="form-control" name="username" value="<?php echo e($data->username); ?>">
                </div>
                <div class="form-group">
                    <label for="">Password</label>
                    <input type="text" class="form-control" name="password" value="<?php echo e($data->password1); ?>">
                </div>
                <div class="form-group">
                    <label for="">Ulangi Password</label>
                    <input type="text" class="form-control" name="password1" value="<?php echo e($data->password1); ?>">
                </div>
                <div class="form-group">
                    <label for="">Nama Member</label>
                    <input type="text" class="form-control" name="nama_member" value="<?php echo e($data->nama_member); ?>">
                </div>
                <div class="form-group">
                    <label for="">Alamat</label>
                    <input type="text" class="form-control" name="alamat" value="<?php echo e($data->alamat); ?>">
                </div>
                <div class="form-group">
                    <label for="">No. KTP</label>
                    <input type="number" class="form-control" name="no_ktp" value="<?php echo e($data->no_ktp); ?>">
                </div>
                <div class="form-group">
                    <label for="">Jenis Kelamin</label>
                    <select name="jenis_kelamin" id="jk"  class="form-control">
                        <option value="Pria">Pria</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>
                <br>
                <button class="btn btn-primary" type="submit">Simpan</button>
              </form>
        </div>
    </div>
</div>
<script>
    $('#jk').val("<?php echo e($data->jenis_kelamin); ?>")
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lantamal2\resources\views/pages/member/edit.blade.php ENDPATH**/ ?>
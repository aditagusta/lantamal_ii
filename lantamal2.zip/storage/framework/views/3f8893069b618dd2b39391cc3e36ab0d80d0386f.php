<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('page','Dashboard'); ?>

<div class="page-inner mt--5">
    <div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="card">
            <div class="card-body" align=center>
                <img src="<?php echo e(asset('logo/logo2-removebg-preview.png')); ?>" alt="..." class="img-fluid" style="width: 150px;height:150px">
                <h1>PANDEKA LAUIK SAKTI</h1>
            </div>
        </div>
    </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\lantamal2\resources\views/home.blade.php ENDPATH**/ ?>